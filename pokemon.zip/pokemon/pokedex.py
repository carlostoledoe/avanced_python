from apodekex import APokedex
class Pokedex(APokedex):
    def __init__(self) -> None:
        self.my_pokemons = []
    def listPokemon(self):
        for pokemon in self.my_pokemons:
            print(self.pokemonInfo(pokemon))

if __name__ == '__main__':
    dex = Pokedex()
    